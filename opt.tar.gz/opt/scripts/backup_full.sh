#!/bin/bash

# backup_full.sh

show_help() {
    echo "Uso: $0 <origen> <destino>"
    echo
    echo "Ejemplo:"
    echo "  $0 /var/log /backup_dir"
    echo
    echo "Opciones:"
    echo "  -help    Muestra esta ayuda"
}

# Ayuda
if [[ "$1" == "-help" ]]; then
    show_help
    exit 0
fi

# Validación de parámetros
if [[ $# -ne 2 ]]; then
    echo "Error: cantidad incorrecta de argumentos."
    show_help
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

# Verificar que el directorio origen exista
if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: el directorio origen no existe."
    exit 1
fi

# Verificar que el directorio destino exista
if [[ ! -d "$DESTINO" ]]; then
    echo "Error: el directorio destino no existe."
    exit 1
fi

# Verificar que los sistemas de archivos estén montados
#if ! mountpoint -q "$ORIGEN"; then
#	echo "Advertencia: $ORIGEN no es un punto de montaje."
#	exit 1
#fi

if ! mountpoint -q "$DESTINO"; then
    echo "Error: el sistema de archivos destino no está montado."
    exit 1
fi

# Fecha en formato ANSI YYYYMMDD
FECHA=$(date +%Y%m%d)

# Obtener nombre base del directorio
DIR_NAME=$(basename "$ORIGEN")

# Nombre del archivo backup
ARCHIVO_BACKUP="${DIR_NAME}_bkp_${FECHA}.tar.gz"

# Crear backup
tar -czf "${DESTINO}/${ARCHIVO_BACKUP}" "$ORIGEN"

# Verificar resultado
if [[ $? -eq 0 ]]; then
    echo "Backup realizado correctamente:"
    echo "${DESTINO}/${ARCHIVO_BACKUP}"
else
    echo "Error al generar el backup."
    exit 1
fi
